<!DOCTYPE html>
<html>
<head>
</head>

<body>
<script type="text/javascript">
	alert("Customer added successfully.");
	</script>
</body>
</html>


