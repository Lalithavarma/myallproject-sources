# Vehicle-Insurnace-Management-System
 DBMS Project

# Frontend Tech Stack
 HTML</br>
 CSS
 
# Backend Tech Stack
 PHP</br>
 MySQL
