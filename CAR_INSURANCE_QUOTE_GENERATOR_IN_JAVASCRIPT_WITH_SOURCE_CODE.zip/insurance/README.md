##### Car Insurance Quote Generator

>This mini application is created to understand the concept of OOPS and Prototype in Javascript

##### Algorithm Behind calculating quote.
Base Prize is Rupees 2000
Each car model has different has different quote increment rate
Each passing year will decrease quote rate by 3%  

##### To Run this application
1. Downlaod zip file
2. Run index.html