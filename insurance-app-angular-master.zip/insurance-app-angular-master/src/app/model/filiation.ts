export class  Filiation {
  id: any;
  name: string;
  address: string;
  phone: string;

}
