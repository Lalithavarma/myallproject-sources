export class InsuranceType {
  id: any;
  name: string;
  agentPercent: number;
}
