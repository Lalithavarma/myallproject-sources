# Vehicle_insurance_management_system
This is Vehicle Insurance Management System Project 

## Technology Used 
1. Backend: Core JAVA, Springboot, Spring Data JPA, Springboot Web, Hiberate, MySQL Database, Thymeleaf.
2. Frontend: HTML, CSS, Bootstrap.; 

## To Run This Project Follow Below Steps :
1. git clone https://github.com/BhartiKhankure/Vehicle_insurance_management_system.git -b main
2. Opne it in eclipse.
3. Then run the application
