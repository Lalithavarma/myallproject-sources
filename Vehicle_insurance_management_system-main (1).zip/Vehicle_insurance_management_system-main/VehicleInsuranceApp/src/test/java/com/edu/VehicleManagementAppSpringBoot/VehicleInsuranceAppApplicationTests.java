package com.edu.VehicleManagementAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleInsuranceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
