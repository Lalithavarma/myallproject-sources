package com.example.LVIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LvisApplicationTests {

	@Test
	void contextLoads() {
	}

}
