package com.example.EmployeeMangementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMangementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMangementSystemApplication.class, args);
	}

}
