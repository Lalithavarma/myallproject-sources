export class Notification {
  constructor(
    public id: string,
    public title: string,
    public description: string,
    public createdAt: number
  ) {}
}
