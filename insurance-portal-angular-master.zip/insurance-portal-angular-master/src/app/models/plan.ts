export class Plan {
  constructor(
    public id: string,
    public name: string,
    public cost: number,
    public deductible: number
  ) {}
}
