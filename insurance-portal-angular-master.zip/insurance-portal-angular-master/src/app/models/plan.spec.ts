import { Plan } from './plan';

describe('Plan', () => {
  it('should create an instance', () => {
    expect(new Plan()).toBeTruthy();
  });
});
