declare let stripe: any;
declare let elements: any;
